/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan.pkg3;
import javax.swing.JOptionPane;

/**
 *
 * @author dell
 */
public class Pertemuan3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      String kondisi;
      kondisi = JOptionPane.showInputDialog(null, "silahkan pilih kondisi : [Biodata, Kalkulator]");
      Pertemuan3 per = new Pertemuan3();
      if (kondisi.equals("Biodata")){
          per.Biodata();
      } else if (kondisi.equals("Kalkulator")){
          per.Kalkulator();
      }
    }
    
    
void Biodata(){
    String nama_depan, nama_belakang, tempat, tgl_lahir, alamat, matkul,grade;
    int nohp,nilai;
    
//        input dengan JOptionPane     

nama_depan = JOptionPane.showInputDialog(null, "masukan nama depan :");
nama_belakang = JOptionPane.showInputDialog(null, "masukan nama belakang :");
tempat = JOptionPane.showInputDialog(null, "Masukan Tempat Lahir Anda :");
tgl_lahir = JOptionPane.showInputDialog(null, "Masukan Tanggal Lahir anda Anda :");
nohp = Integer.parseInt(JOptionPane.showInputDialog(null, "Masukan No Hp Anda :"));
matkul = JOptionPane.showInputDialog(null, "Masukan Nama Matakuliah Anda Hari Ini:");
nilai = Integer.parseInt(JOptionPane.showInputDialog(null, "Masukan Nilai Matakuliah Anda:"));
alamat = JOptionPane.showInputDialog(null, "Masukan Alamat Anda:");

// hitung gradenya
if (nilai > 90 && nilai <=100){
        grade = "A";
    }else if (nilai > 80 && nilai <= 90){
        grade = "B+";
    }else if (nilai > 70 && nilai <=80){
        grade = "B";
    }else if (nilai > 60 && nilai <=70){
        grade = "C+";
    }else if (nilai > 50 && nilai <=60){
        grade = "C";
    }else if (nilai > 40 && nilai <=50){
        grade = "D";
    }else {
        grade = "E";
    }

//cetak hasilnya
    System.out.println("grade:" + grade);

//output popup

JOptionPane.showInputDialog(null, "====Biodata====\n"
    +"nama : "+ nama_depan + " " + nama_belakang + "\n" 
    +"tempat/tanggal lahir : "+ tempat +" /" + tgl_lahir + "\n" 
    +"no Hp : " + nohp + "\n" 
    +"nama Matakuliah Saat Ini : " + matkul + "\n"  
    +"alamat : " + alamat +"\n"
    +"nilai Angka : " + nilai + "\n"
    +"nilai Huruf : " + grade
   );
}
 

void Kalkulator(){
    System.out.println("ini kalkulator");
      String bilangan1,bilangan2;
      int nilai1,nilai2
              
//              input kalkulator menggunakan JOption
              bilangan1 = JOptionPane.showInputDialog(null, "masukan bilangan1=");
              bilangan2 = JOptionPane.showInputDialog(null, "masukan bilangan2=");
              
              nilai1 = Integer.parseInt(bilangan1)
              nilai2 = Integer.parseInt(bilangan2)
                      
              int tambah = nilai1 + nilai2;
              int kurang = nilai1 - nilai2;
              int kali = nilai1 * nilai2;
              int bagi = nilai1 / nilai2;
              
//              output pop up
             JOptionPane.showMessageDialog(null, "hasil dari" + nilai1 + "+" + nilai2 + "adalah" +tambah);
             JOptionPane.showMessageDialog(null, "hasil dari" + nilai1 + "-" + nilai2 + "adalah" +kurang);
             JOptionPane.showMessageDialog(null, "hasil dari" + nilai1 + "*" + nilai2 + "adalah" +kali);
             JOptionPane.showMessageDialog(null, "hasil dari" + nilai1 + "/" + nilai2 + "adalah" +bagi);
}
}
